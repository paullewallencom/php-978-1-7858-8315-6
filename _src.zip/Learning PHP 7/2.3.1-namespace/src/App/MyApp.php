<?php

class MyApp
{
    public function hello()
    {
        echo 'Hello PHP 7';
    }
}
