<?php
require '../src/App/MyApp.php';

$application = new MyApp();
$application->hello();
