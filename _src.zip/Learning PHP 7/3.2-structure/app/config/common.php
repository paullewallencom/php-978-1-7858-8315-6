<?php
$app['twig.path'] = array(__DIR__.'/../../templates');
$app['twig.options'] = array('cache' => __DIR__.'/../cache/twig');
