<?php
//one line comment

/*
Hi
I am
multi-line
comment
*/

/**
 * I am a doc block
 * comment
 */

# I am a shell style comment

echo 'Hello World!';
