<?php
namespace App\Model;

class UserRole
{
    const ROLE_USER = 'user';
    const ROLE_ADMIN = 'admin';
}