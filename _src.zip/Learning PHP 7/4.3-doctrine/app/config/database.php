<?php

$dbConnection = array(
    "driver"    => "pdo_mysql",
    "host"      => "mysql",
    "dbname"    => "mydb",
    "user"      => "dev",
    "password"  => "123456",
    "charset"   => "utf8mb4",
);
