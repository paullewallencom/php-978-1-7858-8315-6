<?php
require '../vendor/autoload.php';

use App\MyApp;

$application = new MyApp();
$application->hello();
